/* Specify the instance specific configurations here.
Refer to the documentation on how to get these details for the Salesforce Commerce API */

var config = {};

config = {
  headers: {},
  parameters: {
    clientId: '7ea1fedf-5c75-4c1f-9625-5a899c9dd7cf',
    organizationId: 'f_ecom_zyzy_015',
    shortCode: 'zv7kzn78',
    siteId: 'RefArch'
  },
  userDetails: {}
}

module.exports = config;